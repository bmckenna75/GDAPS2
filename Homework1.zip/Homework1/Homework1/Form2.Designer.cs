﻿namespace Homework1
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuBar = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem12 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem13 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem14 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem15 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem16 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem17 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem18 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem19 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem20 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem21 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem22 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem23 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem24 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem25 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem26 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem27 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem28 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem29 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem30 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem31 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem32 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem33 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem34 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem35 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem36 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem37 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem38 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem39 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem40 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem41 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem42 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem43 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem44 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem45 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem46 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem47 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem48 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem49 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem50 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem51 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem52 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem53 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem54 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem55 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem56 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem57 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem58 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem59 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem60 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem61 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem62 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem63 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem64 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem65 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem66 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem67 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem68 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem69 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem70 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem71 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem72 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem73 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem74 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem75 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem76 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem77 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem78 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem79 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem80 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem81 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem82 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem83 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem84 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem85 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem86 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem87 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem88 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem89 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem90 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem91 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem92 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem93 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem94 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem95 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem96 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem97 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem98 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem99 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem100 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem101 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem102 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem103 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem104 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem105 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem106 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem107 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem108 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem109 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem110 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem111 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem112 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuBar.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuBar
            // 
            this.menuBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2,
            this.toolStripMenuItem3,
            this.toolStripMenuItem4,
            this.toolStripMenuItem5,
            this.toolStripMenuItem6,
            this.toolStripMenuItem7,
            this.toolStripMenuItem8,
            this.toolStripMenuItem9,
            this.toolStripMenuItem10});
            this.menuBar.Location = new System.Drawing.Point(0, 0);
            this.menuBar.Name = "menuBar";
            this.menuBar.Size = new System.Drawing.Size(1404, 24);
            this.menuBar.TabIndex = 0;
            this.menuBar.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem12,
            this.toolStripMenuItem13,
            this.toolStripMenuItem14,
            this.toolStripMenuItem15,
            this.toolStripMenuItem16,
            this.toolStripMenuItem17,
            this.toolStripMenuItem18,
            this.toolStripMenuItem19,
            this.toolStripMenuItem20,
            this.toolStripMenuItem21});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem1.Text = "1";
            // 
            // toolStripMenuItem12
            // 
            this.toolStripMenuItem12.Name = "toolStripMenuItem12";
            this.toolStripMenuItem12.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem12.Text = "01";
            // 
            // toolStripMenuItem13
            // 
            this.toolStripMenuItem13.Name = "toolStripMenuItem13";
            this.toolStripMenuItem13.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem13.Text = "11";
            // 
            // toolStripMenuItem14
            // 
            this.toolStripMenuItem14.Name = "toolStripMenuItem14";
            this.toolStripMenuItem14.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem14.Text = "21";
            // 
            // toolStripMenuItem15
            // 
            this.toolStripMenuItem15.Name = "toolStripMenuItem15";
            this.toolStripMenuItem15.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem15.Text = "31";
            // 
            // toolStripMenuItem16
            // 
            this.toolStripMenuItem16.Name = "toolStripMenuItem16";
            this.toolStripMenuItem16.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem16.Text = "41";
            // 
            // toolStripMenuItem17
            // 
            this.toolStripMenuItem17.Name = "toolStripMenuItem17";
            this.toolStripMenuItem17.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem17.Text = "51";
            // 
            // toolStripMenuItem18
            // 
            this.toolStripMenuItem18.Name = "toolStripMenuItem18";
            this.toolStripMenuItem18.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem18.Text = "61";
            // 
            // toolStripMenuItem19
            // 
            this.toolStripMenuItem19.Name = "toolStripMenuItem19";
            this.toolStripMenuItem19.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem19.Text = "71";
            // 
            // toolStripMenuItem20
            // 
            this.toolStripMenuItem20.Name = "toolStripMenuItem20";
            this.toolStripMenuItem20.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem20.Text = "81";
            // 
            // toolStripMenuItem21
            // 
            this.toolStripMenuItem21.Name = "toolStripMenuItem21";
            this.toolStripMenuItem21.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem21.Text = "91";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem22,
            this.toolStripMenuItem23,
            this.toolStripMenuItem24,
            this.toolStripMenuItem25,
            this.toolStripMenuItem26,
            this.toolStripMenuItem27,
            this.toolStripMenuItem28,
            this.toolStripMenuItem29,
            this.toolStripMenuItem30,
            this.toolStripMenuItem31});
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem2.Text = "2";
            // 
            // toolStripMenuItem22
            // 
            this.toolStripMenuItem22.Name = "toolStripMenuItem22";
            this.toolStripMenuItem22.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem22.Text = "02";
            // 
            // toolStripMenuItem23
            // 
            this.toolStripMenuItem23.Name = "toolStripMenuItem23";
            this.toolStripMenuItem23.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem23.Text = "12";
            // 
            // toolStripMenuItem24
            // 
            this.toolStripMenuItem24.Name = "toolStripMenuItem24";
            this.toolStripMenuItem24.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem24.Text = "22";
            // 
            // toolStripMenuItem25
            // 
            this.toolStripMenuItem25.Name = "toolStripMenuItem25";
            this.toolStripMenuItem25.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem25.Text = "32";
            // 
            // toolStripMenuItem26
            // 
            this.toolStripMenuItem26.Name = "toolStripMenuItem26";
            this.toolStripMenuItem26.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem26.Text = "42";
            // 
            // toolStripMenuItem27
            // 
            this.toolStripMenuItem27.Name = "toolStripMenuItem27";
            this.toolStripMenuItem27.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem27.Text = "52";
            // 
            // toolStripMenuItem28
            // 
            this.toolStripMenuItem28.Name = "toolStripMenuItem28";
            this.toolStripMenuItem28.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem28.Text = "62";
            // 
            // toolStripMenuItem29
            // 
            this.toolStripMenuItem29.Name = "toolStripMenuItem29";
            this.toolStripMenuItem29.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem29.Text = "72";
            // 
            // toolStripMenuItem30
            // 
            this.toolStripMenuItem30.Name = "toolStripMenuItem30";
            this.toolStripMenuItem30.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem30.Text = "82";
            // 
            // toolStripMenuItem31
            // 
            this.toolStripMenuItem31.Name = "toolStripMenuItem31";
            this.toolStripMenuItem31.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem31.Text = "92";
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem32,
            this.toolStripMenuItem33,
            this.toolStripMenuItem34,
            this.toolStripMenuItem35,
            this.toolStripMenuItem36,
            this.toolStripMenuItem37,
            this.toolStripMenuItem38,
            this.toolStripMenuItem39,
            this.toolStripMenuItem40,
            this.toolStripMenuItem41});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem3.Text = "3";
            // 
            // toolStripMenuItem32
            // 
            this.toolStripMenuItem32.Name = "toolStripMenuItem32";
            this.toolStripMenuItem32.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem32.Text = "03";
            // 
            // toolStripMenuItem33
            // 
            this.toolStripMenuItem33.Name = "toolStripMenuItem33";
            this.toolStripMenuItem33.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem33.Text = "13";
            // 
            // toolStripMenuItem34
            // 
            this.toolStripMenuItem34.Name = "toolStripMenuItem34";
            this.toolStripMenuItem34.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem34.Text = "23";
            // 
            // toolStripMenuItem35
            // 
            this.toolStripMenuItem35.Name = "toolStripMenuItem35";
            this.toolStripMenuItem35.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem35.Text = "33";
            // 
            // toolStripMenuItem36
            // 
            this.toolStripMenuItem36.Name = "toolStripMenuItem36";
            this.toolStripMenuItem36.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem36.Text = "43";
            // 
            // toolStripMenuItem37
            // 
            this.toolStripMenuItem37.Name = "toolStripMenuItem37";
            this.toolStripMenuItem37.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem37.Text = "53";
            // 
            // toolStripMenuItem38
            // 
            this.toolStripMenuItem38.Name = "toolStripMenuItem38";
            this.toolStripMenuItem38.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem38.Text = "63";
            // 
            // toolStripMenuItem39
            // 
            this.toolStripMenuItem39.Name = "toolStripMenuItem39";
            this.toolStripMenuItem39.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem39.Text = "73";
            // 
            // toolStripMenuItem40
            // 
            this.toolStripMenuItem40.Name = "toolStripMenuItem40";
            this.toolStripMenuItem40.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem40.Text = "83";
            // 
            // toolStripMenuItem41
            // 
            this.toolStripMenuItem41.Name = "toolStripMenuItem41";
            this.toolStripMenuItem41.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem41.Text = "93";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem42,
            this.toolStripMenuItem43,
            this.toolStripMenuItem44,
            this.toolStripMenuItem45,
            this.toolStripMenuItem46,
            this.toolStripMenuItem47,
            this.toolStripMenuItem48,
            this.toolStripMenuItem49,
            this.toolStripMenuItem50,
            this.toolStripMenuItem51});
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem4.Text = "4";
            // 
            // toolStripMenuItem42
            // 
            this.toolStripMenuItem42.Name = "toolStripMenuItem42";
            this.toolStripMenuItem42.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem42.Text = "04";
            // 
            // toolStripMenuItem43
            // 
            this.toolStripMenuItem43.Name = "toolStripMenuItem43";
            this.toolStripMenuItem43.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem43.Text = "14";
            // 
            // toolStripMenuItem44
            // 
            this.toolStripMenuItem44.Name = "toolStripMenuItem44";
            this.toolStripMenuItem44.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem44.Text = "24";
            // 
            // toolStripMenuItem45
            // 
            this.toolStripMenuItem45.Name = "toolStripMenuItem45";
            this.toolStripMenuItem45.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem45.Text = "34";
            // 
            // toolStripMenuItem46
            // 
            this.toolStripMenuItem46.Name = "toolStripMenuItem46";
            this.toolStripMenuItem46.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem46.Text = "44";
            // 
            // toolStripMenuItem47
            // 
            this.toolStripMenuItem47.Name = "toolStripMenuItem47";
            this.toolStripMenuItem47.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem47.Text = "54";
            // 
            // toolStripMenuItem48
            // 
            this.toolStripMenuItem48.Name = "toolStripMenuItem48";
            this.toolStripMenuItem48.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem48.Text = "64";
            // 
            // toolStripMenuItem49
            // 
            this.toolStripMenuItem49.Name = "toolStripMenuItem49";
            this.toolStripMenuItem49.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem49.Text = "74";
            // 
            // toolStripMenuItem50
            // 
            this.toolStripMenuItem50.Name = "toolStripMenuItem50";
            this.toolStripMenuItem50.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem50.Text = "84";
            // 
            // toolStripMenuItem51
            // 
            this.toolStripMenuItem51.Name = "toolStripMenuItem51";
            this.toolStripMenuItem51.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem51.Text = "94";
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem52,
            this.toolStripMenuItem53,
            this.toolStripMenuItem54,
            this.toolStripMenuItem55,
            this.toolStripMenuItem56,
            this.toolStripMenuItem57,
            this.toolStripMenuItem58,
            this.toolStripMenuItem59,
            this.toolStripMenuItem60,
            this.toolStripMenuItem61});
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem5.Text = "5";
            // 
            // toolStripMenuItem52
            // 
            this.toolStripMenuItem52.Name = "toolStripMenuItem52";
            this.toolStripMenuItem52.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem52.Text = "05";
            // 
            // toolStripMenuItem53
            // 
            this.toolStripMenuItem53.Name = "toolStripMenuItem53";
            this.toolStripMenuItem53.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem53.Text = "15";
            // 
            // toolStripMenuItem54
            // 
            this.toolStripMenuItem54.Name = "toolStripMenuItem54";
            this.toolStripMenuItem54.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem54.Text = "25";
            // 
            // toolStripMenuItem55
            // 
            this.toolStripMenuItem55.Name = "toolStripMenuItem55";
            this.toolStripMenuItem55.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem55.Text = "35";
            // 
            // toolStripMenuItem56
            // 
            this.toolStripMenuItem56.Name = "toolStripMenuItem56";
            this.toolStripMenuItem56.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem56.Text = "45";
            // 
            // toolStripMenuItem57
            // 
            this.toolStripMenuItem57.Name = "toolStripMenuItem57";
            this.toolStripMenuItem57.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem57.Text = "55";
            // 
            // toolStripMenuItem58
            // 
            this.toolStripMenuItem58.Name = "toolStripMenuItem58";
            this.toolStripMenuItem58.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem58.Text = "65";
            // 
            // toolStripMenuItem59
            // 
            this.toolStripMenuItem59.Name = "toolStripMenuItem59";
            this.toolStripMenuItem59.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem59.Text = "75";
            // 
            // toolStripMenuItem60
            // 
            this.toolStripMenuItem60.Name = "toolStripMenuItem60";
            this.toolStripMenuItem60.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem60.Text = "85";
            // 
            // toolStripMenuItem61
            // 
            this.toolStripMenuItem61.Name = "toolStripMenuItem61";
            this.toolStripMenuItem61.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem61.Text = "95";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem62,
            this.toolStripMenuItem63,
            this.toolStripMenuItem64,
            this.toolStripMenuItem65,
            this.toolStripMenuItem66,
            this.toolStripMenuItem67,
            this.toolStripMenuItem68,
            this.toolStripMenuItem69,
            this.toolStripMenuItem70,
            this.toolStripMenuItem71});
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem6.Text = "6";
            // 
            // toolStripMenuItem62
            // 
            this.toolStripMenuItem62.Name = "toolStripMenuItem62";
            this.toolStripMenuItem62.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem62.Text = "06";
            // 
            // toolStripMenuItem63
            // 
            this.toolStripMenuItem63.Name = "toolStripMenuItem63";
            this.toolStripMenuItem63.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem63.Text = "16";
            // 
            // toolStripMenuItem64
            // 
            this.toolStripMenuItem64.Name = "toolStripMenuItem64";
            this.toolStripMenuItem64.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem64.Text = "26";
            // 
            // toolStripMenuItem65
            // 
            this.toolStripMenuItem65.Name = "toolStripMenuItem65";
            this.toolStripMenuItem65.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem65.Text = "36";
            // 
            // toolStripMenuItem66
            // 
            this.toolStripMenuItem66.Name = "toolStripMenuItem66";
            this.toolStripMenuItem66.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem66.Text = "46";
            // 
            // toolStripMenuItem67
            // 
            this.toolStripMenuItem67.Name = "toolStripMenuItem67";
            this.toolStripMenuItem67.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem67.Text = "56";
            // 
            // toolStripMenuItem68
            // 
            this.toolStripMenuItem68.Name = "toolStripMenuItem68";
            this.toolStripMenuItem68.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem68.Text = "66";
            // 
            // toolStripMenuItem69
            // 
            this.toolStripMenuItem69.Name = "toolStripMenuItem69";
            this.toolStripMenuItem69.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem69.Text = "76";
            // 
            // toolStripMenuItem70
            // 
            this.toolStripMenuItem70.Name = "toolStripMenuItem70";
            this.toolStripMenuItem70.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem70.Text = "86";
            // 
            // toolStripMenuItem71
            // 
            this.toolStripMenuItem71.Name = "toolStripMenuItem71";
            this.toolStripMenuItem71.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem71.Text = "96";
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem72,
            this.toolStripMenuItem73,
            this.toolStripMenuItem74,
            this.toolStripMenuItem75,
            this.toolStripMenuItem76,
            this.toolStripMenuItem77,
            this.toolStripMenuItem78,
            this.toolStripMenuItem79,
            this.toolStripMenuItem80,
            this.toolStripMenuItem81});
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem7.Text = "7";
            // 
            // toolStripMenuItem72
            // 
            this.toolStripMenuItem72.Name = "toolStripMenuItem72";
            this.toolStripMenuItem72.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem72.Text = "07";
            // 
            // toolStripMenuItem73
            // 
            this.toolStripMenuItem73.Name = "toolStripMenuItem73";
            this.toolStripMenuItem73.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem73.Text = "17";
            // 
            // toolStripMenuItem74
            // 
            this.toolStripMenuItem74.Name = "toolStripMenuItem74";
            this.toolStripMenuItem74.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem74.Text = "27";
            // 
            // toolStripMenuItem75
            // 
            this.toolStripMenuItem75.Name = "toolStripMenuItem75";
            this.toolStripMenuItem75.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem75.Text = "37";
            // 
            // toolStripMenuItem76
            // 
            this.toolStripMenuItem76.Name = "toolStripMenuItem76";
            this.toolStripMenuItem76.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem76.Text = "47";
            // 
            // toolStripMenuItem77
            // 
            this.toolStripMenuItem77.Name = "toolStripMenuItem77";
            this.toolStripMenuItem77.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem77.Text = "57";
            // 
            // toolStripMenuItem78
            // 
            this.toolStripMenuItem78.Name = "toolStripMenuItem78";
            this.toolStripMenuItem78.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem78.Text = "67";
            // 
            // toolStripMenuItem79
            // 
            this.toolStripMenuItem79.Name = "toolStripMenuItem79";
            this.toolStripMenuItem79.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem79.Text = "77";
            // 
            // toolStripMenuItem80
            // 
            this.toolStripMenuItem80.Name = "toolStripMenuItem80";
            this.toolStripMenuItem80.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem80.Text = "87";
            // 
            // toolStripMenuItem81
            // 
            this.toolStripMenuItem81.Name = "toolStripMenuItem81";
            this.toolStripMenuItem81.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem81.Text = "97";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem82,
            this.toolStripMenuItem83,
            this.toolStripMenuItem84,
            this.toolStripMenuItem85,
            this.toolStripMenuItem86,
            this.toolStripMenuItem87,
            this.toolStripMenuItem88,
            this.toolStripMenuItem89,
            this.toolStripMenuItem90,
            this.toolStripMenuItem91});
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem8.Text = "8";
            // 
            // toolStripMenuItem82
            // 
            this.toolStripMenuItem82.Name = "toolStripMenuItem82";
            this.toolStripMenuItem82.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem82.Text = "08";
            // 
            // toolStripMenuItem83
            // 
            this.toolStripMenuItem83.Name = "toolStripMenuItem83";
            this.toolStripMenuItem83.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem83.Text = "18";
            // 
            // toolStripMenuItem84
            // 
            this.toolStripMenuItem84.Name = "toolStripMenuItem84";
            this.toolStripMenuItem84.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem84.Text = "28";
            // 
            // toolStripMenuItem85
            // 
            this.toolStripMenuItem85.Name = "toolStripMenuItem85";
            this.toolStripMenuItem85.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem85.Text = "38";
            // 
            // toolStripMenuItem86
            // 
            this.toolStripMenuItem86.Name = "toolStripMenuItem86";
            this.toolStripMenuItem86.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem86.Text = "48";
            // 
            // toolStripMenuItem87
            // 
            this.toolStripMenuItem87.Name = "toolStripMenuItem87";
            this.toolStripMenuItem87.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem87.Text = "58";
            // 
            // toolStripMenuItem88
            // 
            this.toolStripMenuItem88.Name = "toolStripMenuItem88";
            this.toolStripMenuItem88.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem88.Text = "68";
            // 
            // toolStripMenuItem89
            // 
            this.toolStripMenuItem89.Name = "toolStripMenuItem89";
            this.toolStripMenuItem89.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem89.Text = "78";
            // 
            // toolStripMenuItem90
            // 
            this.toolStripMenuItem90.Name = "toolStripMenuItem90";
            this.toolStripMenuItem90.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem90.Text = "88";
            // 
            // toolStripMenuItem91
            // 
            this.toolStripMenuItem91.Name = "toolStripMenuItem91";
            this.toolStripMenuItem91.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem91.Text = "98";
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem92,
            this.toolStripMenuItem93,
            this.toolStripMenuItem94,
            this.toolStripMenuItem95,
            this.toolStripMenuItem96,
            this.toolStripMenuItem97,
            this.toolStripMenuItem98,
            this.toolStripMenuItem99,
            this.toolStripMenuItem100,
            this.toolStripMenuItem101});
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem9.Text = "9";
            // 
            // toolStripMenuItem92
            // 
            this.toolStripMenuItem92.Name = "toolStripMenuItem92";
            this.toolStripMenuItem92.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem92.Text = "09";
            // 
            // toolStripMenuItem93
            // 
            this.toolStripMenuItem93.Name = "toolStripMenuItem93";
            this.toolStripMenuItem93.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem93.Text = "19";
            // 
            // toolStripMenuItem94
            // 
            this.toolStripMenuItem94.Name = "toolStripMenuItem94";
            this.toolStripMenuItem94.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem94.Text = "29";
            // 
            // toolStripMenuItem95
            // 
            this.toolStripMenuItem95.Name = "toolStripMenuItem95";
            this.toolStripMenuItem95.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem95.Text = "39";
            // 
            // toolStripMenuItem96
            // 
            this.toolStripMenuItem96.Name = "toolStripMenuItem96";
            this.toolStripMenuItem96.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem96.Text = "49";
            // 
            // toolStripMenuItem97
            // 
            this.toolStripMenuItem97.Name = "toolStripMenuItem97";
            this.toolStripMenuItem97.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem97.Text = "59";
            // 
            // toolStripMenuItem98
            // 
            this.toolStripMenuItem98.Name = "toolStripMenuItem98";
            this.toolStripMenuItem98.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem98.Text = "69";
            // 
            // toolStripMenuItem99
            // 
            this.toolStripMenuItem99.Name = "toolStripMenuItem99";
            this.toolStripMenuItem99.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem99.Text = "79";
            // 
            // toolStripMenuItem100
            // 
            this.toolStripMenuItem100.Name = "toolStripMenuItem100";
            this.toolStripMenuItem100.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem100.Text = "89";
            // 
            // toolStripMenuItem101
            // 
            this.toolStripMenuItem101.Name = "toolStripMenuItem101";
            this.toolStripMenuItem101.Size = new System.Drawing.Size(86, 22);
            this.toolStripMenuItem101.Text = "99";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem102,
            this.toolStripMenuItem103,
            this.toolStripMenuItem104,
            this.toolStripMenuItem105,
            this.toolStripMenuItem106,
            this.toolStripMenuItem107,
            this.toolStripMenuItem108,
            this.toolStripMenuItem109,
            this.toolStripMenuItem110,
            this.toolStripMenuItem111,
            this.toolStripMenuItem112});
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(25, 20);
            this.toolStripMenuItem10.Text = "0";
            // 
            // toolStripMenuItem102
            // 
            this.toolStripMenuItem102.Name = "toolStripMenuItem102";
            this.toolStripMenuItem102.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem102.Text = "00";
            // 
            // toolStripMenuItem103
            // 
            this.toolStripMenuItem103.Name = "toolStripMenuItem103";
            this.toolStripMenuItem103.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem103.Text = "10";
            // 
            // toolStripMenuItem104
            // 
            this.toolStripMenuItem104.Name = "toolStripMenuItem104";
            this.toolStripMenuItem104.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem104.Text = "20";
            // 
            // toolStripMenuItem105
            // 
            this.toolStripMenuItem105.Name = "toolStripMenuItem105";
            this.toolStripMenuItem105.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem105.Text = "30";
            // 
            // toolStripMenuItem106
            // 
            this.toolStripMenuItem106.Name = "toolStripMenuItem106";
            this.toolStripMenuItem106.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem106.Text = "40";
            // 
            // toolStripMenuItem107
            // 
            this.toolStripMenuItem107.Name = "toolStripMenuItem107";
            this.toolStripMenuItem107.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem107.Text = "50";
            // 
            // toolStripMenuItem108
            // 
            this.toolStripMenuItem108.Name = "toolStripMenuItem108";
            this.toolStripMenuItem108.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem108.Text = "60";
            // 
            // toolStripMenuItem109
            // 
            this.toolStripMenuItem109.Name = "toolStripMenuItem109";
            this.toolStripMenuItem109.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem109.Text = "70";
            // 
            // toolStripMenuItem110
            // 
            this.toolStripMenuItem110.Name = "toolStripMenuItem110";
            this.toolStripMenuItem110.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem110.Text = "80";
            // 
            // toolStripMenuItem111
            // 
            this.toolStripMenuItem111.Name = "toolStripMenuItem111";
            this.toolStripMenuItem111.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem111.Text = "90";
            // 
            // toolStripMenuItem112
            // 
            this.toolStripMenuItem112.Name = "toolStripMenuItem112";
            this.toolStripMenuItem112.Size = new System.Drawing.Size(92, 22);
            this.toolStripMenuItem112.Text = "100";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepPink;
            this.ClientSize = new System.Drawing.Size(1404, 60);
            this.Controls.Add(this.menuBar);
            this.MainMenuStrip = this.menuBar;
            this.Name = "Form2";
            this.Text = "Volume Adjuster";
            this.menuBar.ResumeLayout(false);
            this.menuBar.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuBar;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem12;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem13;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem14;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem15;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem16;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem17;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem18;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem19;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem20;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem21;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem22;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem23;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem24;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem25;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem26;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem27;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem28;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem29;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem30;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem31;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem32;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem33;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem34;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem35;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem36;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem37;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem38;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem39;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem40;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem41;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem42;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem43;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem44;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem45;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem46;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem47;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem48;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem49;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem50;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem51;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem52;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem53;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem54;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem55;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem56;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem57;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem58;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem59;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem60;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem61;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem62;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem63;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem64;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem65;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem66;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem67;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem68;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem69;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem70;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem71;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem72;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem73;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem74;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem75;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem76;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem77;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem78;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem79;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem80;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem81;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem82;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem83;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem84;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem85;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem86;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem87;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem88;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem89;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem90;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem91;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem92;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem93;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem94;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem95;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem96;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem97;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem98;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem99;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem100;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem101;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem102;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem103;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem104;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem105;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem106;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem107;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem108;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem109;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem110;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem111;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem112;
    }
}